# Hullproof Free pack 0.5.0

This pack holds the Hullproof security standard and the prompts that run a security audit of your own project inside an AI tool that has no Hullproof installer, such as a chat app or an app builder.

How to use it:

1. Upload this zip file to the chat or project of your AI tool.
2. Open `INSTALL-BY-CHAT.md` from this pack, paste its text into the same chat, and send it. The tool unzips the pack and places the files at your project root. It tells you what it placed and what it could not place.
3. Start the audit by saying: Run the Hullproof audit using prompts/HULLPROOF-AUDIT-PROMPT.md. If your tool limits the size of instructions, use prompts/HULLPROOF-AUDIT-PROMPT-SHORT.md instead.

What is inside:

- `INSTALL-BY-CHAT.md`: the install prompt.
- `prompts/`: the full audit prompt, the short audit prompt and the other Hullproof prompts.
- `docs/hullproof/`: the requirements, checklists and report templates the prompts read.
- `editors/`: the rules file for each tool and a short page on how that tool uses it.

Limits you should know. A prompt is a request and not a control. In a chat tool or an app builder, nothing stops the tool from writing a file or running a command unless the tool itself has a read only mode. The audit report says at the top whether the run had an enforced read only limit. If the tool cannot read your whole project, the report lists what it could not read and marks those parts as not assessed.
